// Deprecated service. All logic moved to LocalDB/Firestore.
export const pb = null;
export const logout = () => {};
