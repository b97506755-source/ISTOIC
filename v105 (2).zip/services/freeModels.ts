
import { MASTER_MODEL_CATALOG } from "./modelRegistry";

/**
 * @deprecated Use MASTER_MODEL_CATALOG from 'services/modelRegistry' instead.
 * This file is kept for backward compatibility and will be removed in future versions.
 */
export const FREE_TIER_MODELS = MASTER_MODEL_CATALOG;
