
import { Note } from '../types';

export const useFirestoreSync = (_localNotes: Note[], _setLocalNotes: (notes: Note[]) => void) => {
    // Sync removed
};